# Design System: High-End Editorial Dashboard (Arabic)

## 1. Overview & Creative North Star
### Creative North Star: "The Digital Curator"
This design system moves away from the rigid, boxed-in nature of traditional SaaS dashboards and toward a "Digital Curator" experience. It treats data not as a series of rows and columns, but as editorial content housed within a sophisticated, airy environment.

**Beyond the Template:**
We break the "standard dashboard" look by utilizing **intentional white space**, **RTL-first hierarchy**, and **tonal layering**. In an Arabic administrative context, clarity and speed are paramount. By removing distracting lines and focusing on surface-to-surface depth, we allow the content (the data) to breathe, reducing cognitive load while maintaining a premium, high-density experience.

---

## 2. Colors
Our palette is rooted in a crisp, luminous foundation with precision-engineered blues for action and authority.

### The "No-Line" Rule
**Explicit Instruction:** Do not use 1px solid borders to define sections or containers. 
Boundaries must be defined through background color shifts. A `surface-container-lowest` card sits atop a `surface-container-low` section to create distinction. This removes visual "noise" and allows the eye to glide across the interface.

### Surface Hierarchy & Nesting
Treat the UI as a series of physical layers:
- **`surface` (#f9f9fb):** The global canvas.
- **`surface-container-low` (#f3f3f5):** Used for sidebar backgrounds or secondary content zones.
- **`surface-container-lowest` (#ffffff):** Reserved for primary interactive cards and data tables.
- **`surface-bright` (#f9f9fb):** Used for emphasis within sections to draw the user’s eye.

### The "Glass & Gradient" Rule
Floating elements (modals, dropdowns, sticky headers) should utilize **Glassmorphism**. Apply a semi-transparent surface color with a `backdrop-blur` of 8px–12px. This ensures the dashboard feels integrated and multidimensional. 

**Signature Texture:** Use a subtle linear gradient on primary CTAs—transitioning from `primary` (#2642e6) to `primary_container` (#465fff) at a 135-degree angle—to provide depth that flat colors cannot achieve.

---

## 3. Typography
**Typeface:** IBM Plex Sans Arabic
The typography system is designed to handle the unique vertical rhythm and character density of the Arabic script.

*   **Display/Headline:** Use `headline-lg` for dashboard titles to establish a strong editorial "masthead."
*   **Title:** `title-md` and `title-sm` are the workhorses for card headers and section titles, providing clarity in dense data environments.
*   **Body:** `body-md` is the standard for data entry and reading.
*   **Labels:** `label-sm` is used for metadata and micro-copy, ensuring high data density without losing legibility.

**RTL Hierarchy:** Weights should be used purposefully. Bold weights are reserved for critical data points (e.g., total count in a stat card) to create a clear "scan-path" from right to left.

---

## 4. Elevation & Depth
Depth is achieved through **Tonal Layering** rather than structural shadows.

### The Layering Principle
*   **Stacking:** A `surface-container-lowest` card (#FFFFFF) placed on a `surface-container-low` (#F3F3F5) background creates an effortless lift. This is our primary method of elevation.

### Ambient Shadows
For floating elements like "Active Tasks" or "User Profiles" that require actual elevation:
*   **Shadow Specs:** `0px 10px 40px rgba(26, 28, 29, 0.06)`
*   **The Rule:** Shadows must be extremely diffused and low-opacity. Use a tinted version of `on_surface` to mimic natural light rather than a harsh grey.

### The "Ghost Border" Fallback
If accessibility requirements demand a border (e.g., in high-contrast modes), use a **Ghost Border**: `outline_variant` (#c5c5d8) at **15% opacity**. Never use 100% opaque borders.

---

## 5. Components

### Sidebar Layout
The sidebar should utilize `surface-container-low`. The active state should not be a simple color change but a **high-contrast pill** using the `primary` color (#2642e6) with `on_primary` text, floating within the container to emphasize the "Curator" aesthetic.

### Buttons
*   **Primary:** Gradient `primary` to `primary_container`. `Roundedness: md (0.75rem)`.
*   **Secondary:** `surface-container-highest` background with `primary` text. No border.
*   **Tertiary:** Transparent background, `on_surface_variant` text, appearing only on hover.

### Data Cards & Lists
*   **Rule:** Forbid divider lines between list items. Use the **Spacing Scale** (specifically `spacing.4` or `spacing.5`) to create separation.
*   **Density:** For high-density dashboards, use `surface-container-lowest` backgrounds for rows, with a 2px vertical gap to reveal the `surface-container-low` background beneath.

### Input Fields
*   **Style:** `surface-container-low` background with a `Ghost Border` (10% opacity). 
*   **Focus State:** Shift background to `surface-container-lowest` and increase the ghost border opacity to 40% using the `primary` color.

### Iconography
*   **Style:** Line icons with a consistent 1.5px stroke. Use "duotone" sparingly, where the secondary element of the icon uses `primary` at 20% opacity to add a signature brand touch.

---

## 6. Do's and Don'ts

### Do
*   **Do** prioritize the right-to-left flow for all navigation and data visualizations.
*   **Do** use `spacing.10` (2.25rem) for major section gutters to maintain the "Editorial" feel.
*   **Do** leverage typography scale over color to show importance.
*   **Do** use rounded corners (`lg`: 1rem) for large layout containers to soften the administrative feel.

### Don't
*   **Don't** use 1px solid #000 or high-contrast grey borders.
*   **Don't** use standard "drop shadows" with high opacity or small blur radii.
*   **Don't** crowd the interface. If the data is dense, increase the surface-to-surface contrast rather than adding more lines.
*   **Don't** use generic blue (#0000FF). Stick strictly to the refined `primary` (#2642e6) and its containers.